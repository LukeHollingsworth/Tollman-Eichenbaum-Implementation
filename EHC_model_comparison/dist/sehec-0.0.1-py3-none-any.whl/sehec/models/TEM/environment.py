import numpy as np
import copy as cp

